package com.nc.jpa_exercise1.ProductController;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.nc.jpa_exercise1.ProductEntity.Product;
import com.nc.jpa_exercise1.ProductRepo.ProductRepo;
import com.nc.jpa_exercise1.ProductServiceImpl.ProductRestService;

@RestController
public class ProductAPIController {
	
	@Autowired
	private ProductRepo repo;
	
	@Autowired
	ProductRestService productService;
	
	@GetMapping("/api/products")
	public List<Product> showIndexPage() {
		
	     return repo.findAll();
	}
	
	@GetMapping("/api/products/{id}")
	public Optional<Product> findById(@PathVariable long id) {
				
		return repo.findById(id);
	}
	
	@DeleteMapping("/api/products/{id}")
	public String deleteByID(@PathVariable long id) {
		
		repo.deleteById(id);
		return "Product(s) Deleted from the database";
		
	}
	
	@PostMapping("api/products/save")
	public String saveProduct(@RequestBody Product p) {
		
		return productService.save(p) + "Product(s) saved successfully";
	}
	
	@PutMapping("api/products/{id}")
	public String UpdateProduct(@RequestBody Product p, @PathVariable int id) {
		return productService.update(p,id) + "Product(s) updated Successful";
	}
	
	

}
