package com.nc.jpa_exercise1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JpaExercise1Application {

	public static void main(String[] args) {
		SpringApplication.run(JpaExercise1Application.class, args);
	}

}
