package com.nc.jpa_exercise1.ProductServiceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import com.nc.jpa_exercise1.ProductEntity.Product;

@Service
public class ProductRestService{

	@Autowired
	JdbcTemplate template;
	
	public int save(Product p) {
		int sql = template.update("INSERT INTO tbl_products(name,price,photo_name,photo_data) VALUES(?,?,?,?)", new Object[] {p.getName(),p.getPrice(),p.getPhoto_name(),p.getPhoto_data()});
		return sql;
	}
	
	public int update(Product p, int id) {
		int sql = template.update("UPDATE tbl_products SET name=?,price=?,photo_name=?,photo_data=? WHERE id=?", new Object[] {p.getName(),p.getPrice(),p.getPhoto_name(),p.getPhoto_data(),id});
		return sql;
	}

}
