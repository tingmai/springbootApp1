package com.nc.jpa_exercise1.ProductService;
import java.util.List;
import java.util.Optional;

import com.nc.jpa_exercise1.ProductEntity.Product;

public interface ProductService {
	
	public List<Product> getProducts();
	public Product saveProduct(Product product);
	public Product getProduct(Long id);
	public Optional<Product> getProductById(Long id);
	public void deleteProduct(Long id);
	
	

}
