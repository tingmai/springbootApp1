package com.nc.jpa_exercise1.ProductRepo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.nc.jpa_exercise1.ProductEntity.Product;

@Repository
public interface ProductRepo extends JpaRepository<Product, Long>{

}