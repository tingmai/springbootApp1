package com.nc.jpa_exercise1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JpaExercise1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
